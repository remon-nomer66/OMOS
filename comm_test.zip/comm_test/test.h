/**
 * test.h
 **/

#ifndef _INCLUDE_TEST_FUNC_
#define _INCLUDE_TEST_FUNC_

#define TEST    "TEST"

#define E_CODE_1001 1001    //test_func.cにおいて引数不正

#endif
